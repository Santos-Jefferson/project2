//setting express
var express = require('express');
var app = express();
var bodyParser = require('body-parser');
const { Pool, Client } = require('pg');

const pool = new Pool({
	user: 'postgres',
	host: 'localhost',
	database: 'familyBudget',
	password: 'aaml0509',
	port: 5432,
});

const client = new Client({
	user: 'postgres',
	host: 'localhost',
	database: 'familyBudget',
	password: 'aaml0509',
	port: 5432,
});

//connecting postgres
client.connect();

app.use(bodyParser.urlencoded({
	extended: true
}));

app.use(bodyParser.json());

app.post("/myaction", function (req, res){
	//variables coming from HTML FORM method POST
	var date = req.body.date;
	var amount = req.body.amount;
	var description = req.body.description;
	var category = req.body.category;
	
	//Inserting a data to database by string
	const queryInsert = 'INSERT INTO expense(date, amount, categoryid, description, familyid) VALUES($1, $2, $3, $4, $5)';
	const values = [date, amount, 1, description, 1];

	client.query(queryInsert, values, (err, res)=> {
	if (err) {
		console.log(err.stack)
	} else {
		console.log(res.rows[0])
	}
	
});
	
	
	//console.log(date);
});

/*
client.query('SELECT $1::text as message', ['Hello world!'], (err, res) => {
	console.log(err ? err.stack : res.rows[0].message);
	client.end();
});
*/


/*
const query = {
	name: 'fetch-family', 
	text: 'SELECT * FROM family WHERE familyid = $1', 
	values: [1]
}

client.query(query, (err,res) => {
	if (err){
		console.log(err.stack)
	} else {
		console.log(res.rows[0])
	}
})
*/



//webserver
app.set('port', (process.env.PORT || 5000));

app.use(express.static(__dirname + '/public'));

//folder with main pages
app.set('views', __dirname + '/views');

//set the view engine to ejs
app.set('view engine', 'ejs')

//home page
app.get('/', function(req, res){
	res.render('home');
});

//form (myaction)
app.get('/myaction', function(req, res){
	res.render('form');
});

app.listen(app.get('port'), function(){
	console.log('Node app is running on port', app.get('port'));
});

